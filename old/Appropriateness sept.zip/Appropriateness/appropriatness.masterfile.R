rm(list=ls())
setwd("/Users/dorotheespuhler/Dropbox\ (Personal)/PHD\ Dropbox/1\ MODELLING/R/Appropriateness/")
library(triangle)
library (trapezoid)
library(gridExtra)
library(ColorPalette)

#------------------------------------------------------------------------------------------------------------------------
#Create the list of technology appropriateness functions and the list o case appropriateness functions

source("listread.r") # reads the csv data files for technologies and cases descriptions
source("req.functions.r") # contains functions that are not provided in R such as ranges

techlist<- build.list("techdata.csv",3)
str(techlist)
#grid.table(techlist)
#print.data.frame(techlist)
#write.table(techlist)

caselist<- build.list("casedata.csv",2)
str(caselist)

#------------------------------------------------------------------------------------------------------------------------
#

source("app.profile.r") # function to calculate scores for each pair of tech and case attributes functions
source("app.score.r") # functions to calculate overall score for a tech in a given case 

app.profile.septic.tank <- app.profile(techlist$septic.tank,caselist$arbaminch)
app.profile.septic.tank
app.score.septic.tank <- app.score(techlist$septic.tank,caselist$arbaminch)
app.score.septic.tank

app.profile.single.pit<- app.profile(techlist$single.pit,caselist$arbaminch)
app.profile.single.pit
app.score.single.pit <- app.score(techlist$single.pit,caselist$arbaminch)
app.score.single.pit

app.profile.double.pit<- app.profile(techlist$double.pit,caselist$arbaminch)
app.profile.double.pit
app.score.double.pit <- app.score(techlist$double.pit,caselist$arbaminch)
app.score.double.pit
