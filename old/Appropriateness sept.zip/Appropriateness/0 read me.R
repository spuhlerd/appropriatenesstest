To dos:
- plots and secondary data
- read tech and caselist in table form
- write results to csv file
- include ranking
- expand to technologies and attributes

Write here how to fill in the case and techdata files, e.g. provide catalogue of functions (description, usage, arguments)